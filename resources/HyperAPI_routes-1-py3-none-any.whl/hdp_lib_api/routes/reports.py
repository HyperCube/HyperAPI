from hdp_lib_api.base.resource import Resource
from hdp_lib_api.base.route import Route


class Reports(Resource):
    name = "Reports"
    available_since = "3.0"
    removed_since = None

    class _exportProjectReports(Route):
        name = "exportProjectReports"
        httpMethod = Route.GET
        path = "/projects/{project_ID}/reports"
        _path_keys = {
            'project_ID': Route.VALIDATOR_OBJECTID,
        }

    class _exportDatasetReports(Route):
        name = "exportDatasetReports"
        httpMethod = Route.GET
        path = "/projects/{project_ID}/datasets/{dataset_ID}/reports"
        _path_keys = {
            'project_ID': Route.VALIDATOR_OBJECTID,
            'dataset_ID': Route.VALIDATOR_OBJECTID,
        }
