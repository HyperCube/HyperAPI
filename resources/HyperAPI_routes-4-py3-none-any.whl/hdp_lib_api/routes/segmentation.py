from hdp_lib_api.base.resource import Resource
from hdp_lib_api.base.route import Route, SubRoute


class Segmentation(Resource):
    name = "segmentation"
    available_since = "5.0.0"
    removed_since = None

    class _segmentation(Route):
        name = "segmentation"
        removed_since = "5.2.0"
        httpMethod = Route.POST
        path = "/projects/{project_ID}/datasets/segmentation"
        _path_keys = {
            'project_ID': Route.VALIDATOR_OBJECTID
        }

        class _segmentation_v52(SubRoute):
            name = "segmentation"
            removed_since = "6.0.0"
            httpMethod = Route.POST
            path = "/projects/{project_ID}/datasets/segmentations"
            _path_keys = {
                'project_ID': Route.VALIDATOR_OBJECTID
            }

        class _segmentation_v60(SubRoute):
            name = "segmentation"
            available_since = "6.0.0"
            httpMethod = Route.POST
            path = "/swp/projects/{project_ID}/datasets/{dataset_ID}/segmentations"
            _path_keys = {
                'project_ID': Route.VALIDATOR_OBJECTID,
                'dataset_ID': Route.VALIDATOR_OBJECTID
            }

    class _saveSegmentation(Route):
        name = "saveSegmentation"
        available_since = "5.2.0"
        removed_since = "6.0.0"
        httpMethod = Route.POST
        path = "/projects/{project_ID}/datasets/{dataset_ID}/segmentations"
        _path_keys = {
            'project_ID': Route.VALIDATOR_OBJECTID,
            'dataset_ID': Route.VALIDATOR_OBJECTID
        }

        class _saveSegmentation_v60(SubRoute):
            name = "saveSegmentation"
            available_since = "6.0.0"
            httpMethod = Route.POST
            path = "/swp/projects/{project_ID}/datasets/{dataset_ID}/segmentations/save"
            _path_keys = {
                'project_ID': Route.VALIDATOR_OBJECTID,
                'dataset_ID': Route.VALIDATOR_OBJECTID
            }

    class _listSegmentations(Route):
        name = "listSegmentations"
        available_since = "5.2.0"
        removed_since = "6.0.0"
        httpMethod = Route.GET
        path = "/projects/{project_ID}/datasets/{dataset_ID}/segmentations"
        _path_keys = {
            'project_ID': Route.VALIDATOR_OBJECTID,
            'dataset_ID': Route.VALIDATOR_OBJECTID
        }

        class _listSegmentations_v60(SubRoute):
            name = "listSegmentations"
            available_since = "6.0.0"
            httpMethod = Route.GET
            path = "/swp/projects/{project_ID}/datasets/{dataset_ID}/segmentations"
            _path_keys = {
                'project_ID': Route.VALIDATOR_OBJECTID,
                'dataset_ID': Route.VALIDATOR_OBJECTID
            }

    class _rateModel(Route):
        name = "rateModel"
        removed_since = "6.0.0"
        httpMethod = Route.POST
        path = "/projects/{project_ID}/datasets/rateModel"
        _path_keys = {
            'project_ID': Route.VALIDATOR_OBJECTID
        }

        class _rateModel_v60(SubRoute):
            name = "rateModel"
            available_since = "6.0.0"
            httpMethod = Route.POST
            path = "/swp/projects/{project_ID}/datasets/rateModel"
            _path_keys = {
                'project_ID': Route.VALIDATOR_OBJECTID
            }
