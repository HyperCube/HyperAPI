from hdp_lib_api.base.resource import Resource
from hdp_lib_api.base.route import Route


class DashboardPowerBI(Resource):
    name = "DashboardPowerBI"
    available_since = "6.1.0"
    removed_since = None

    class _createDataset(Route):
        name = "createDataset"
        httpMethod = Route.POST
        available_since = "6.1.0"
        httpMethod = Route.POST
        path = "/swp/projects/{project_ID}/datasets/dashboardPowerBI/createDataset"
        _path_keys = {
            'project_ID': Route.VALIDATOR_OBJECTID,
        }
