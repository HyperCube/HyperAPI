from hdp_lib_api.base.resource import Resource
from hdp_lib_api.base.route import Route, SubRoute


class JoinDatasets(Resource):
    name = "joinDatasets"
    available_since = "3.0"
    removed_since = None

    class _joinDatasets(Route):
        name = "joinDatasets"
        removed_since = "6.0.0"
        httpMethod = Route.POST
        path = "/projects/{project_ID}/datasets/join"
        _path_keys = {
            'project_ID': Route.VALIDATOR_OBJECTID
        }

        class _joinDatasets_v60(SubRoute):
            name = "joinDatasets"
            available_since = "6.0.0"
            httpMethod = Route.POST
            path = "/swp/projects/{project_ID}/datasets/join"
            _path_keys = {
                'project_ID': Route.VALIDATOR_OBJECTID
            }

    class _compareDatasets(Route):
        name = "compareDatasets"
        removed_since = "6.0.0"
        httpMethod = Route.POST
        path = "/projects/{project_ID}/datasets/compare"
        _path_keys = {
            'project_ID': Route.VALIDATOR_OBJECTID
        }

        class _compareDatasets_v60(SubRoute):
            name = "compareDatasets"
            available_since = "6.0.0"
            httpMethod = Route.POST
            path = "/swp/projects/{project_ID}/datasets/compare"
            _path_keys = {
                'project_ID': Route.VALIDATOR_OBJECTID
            }
