from hdp_lib_api.base.resource import Resource
from hdp_lib_api.base.route import Route


class Modalities(Resource):
    name = "modalities"
    available_since = "5.2.0"
    removed_since = None

    class _getCommonModalities(Route):
        name = "getCommonModalities"
        httpMethod = Route.POST
        path = "/projects/{project_ID}/datasets/getModalities"
        _path_keys = {
            'project_ID': Route.VALIDATOR_OBJECTID
        }
