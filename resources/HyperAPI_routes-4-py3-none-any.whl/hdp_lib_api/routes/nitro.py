from hdp_lib_api.base.resource import Resource
from hdp_lib_api.base.route import Route, SubRoute


class Nitro(Resource):
    name = "nitro"
    available_since = "1.0"
    removed_since = None

    class _getForecasts(Route):
        name = "getForecasts"
        httpMethod = Route.GET
        removed_since = "3.0"
        path = "/nitro/projects/{project_ID}/datasets/{dataset_ID}/forecasts"
        _path_keys = {
            'project_ID': Route.VALIDATOR_OBJECTID,
            'dataset_ID': Route.VALIDATOR_OBJECTID
        }

        class _getForecastsPost(SubRoute):
            name = "getForecasts"
            httpMethod = Route.POST
            available_since = "3.0"
            path = "/nitro/projects/{project_ID}/datasets/{dataset_ID}/forecasts"
            _path_keys = {
                'project_ID': Route.VALIDATOR_OBJECTID,
                'dataset_ID': Route.VALIDATOR_OBJECTID
            }

    class _postForecasts(Route):
        name = "getForecasts"
        httpMethod = Route.POST
        path = "/nitro/projects/{project_ID}/datasets/{dataset_ID}/forecasts"
        _path_keys = {
            'project_ID': Route.VALIDATOR_OBJECTID,
            'dataset_ID': Route.VALIDATOR_OBJECTID
        }

    class _getForecast(Route):
        name = "getForecast"
        httpMethod = Route.GET
        path = "/nitro/projects/{project_ID}/datasets/{dataset_ID}/forecasts/{forecast_ID}"
        _path_keys = {
            'project_ID': Route.VALIDATOR_OBJECTID,
            'dataset_ID': Route.VALIDATOR_OBJECTID,
            'forecast_ID': Route.VALIDATOR_OBJECTID
        }

    class _insertForecast(Route):
        name = "insertForecast"
        httpMethod = Route.POST
        available_since = "3.0"
        path = "/nitro/projects/{project_ID}/datasets/{dataset_ID}/forecasts/add"
        _path_keys = {
            'project_ID': Route.VALIDATOR_OBJECTID,
            'dataset_ID': Route.VALIDATOR_OBJECTID
        }

    class _updateForecast(Route):
        name = "updateForecast"
        httpMethod = Route.POST
        path = "/nitro/projects/{project_ID}/datasets/{dataset_ID}/forecasts/{forecast_ID}"
        _path_keys = {
            'project_ID': Route.VALIDATOR_OBJECTID,
            'dataset_ID': Route.VALIDATOR_OBJECTID,
            'forecast_ID': Route.VALIDATOR_OBJECTID
        }

    class _updateForecastCoef(Route):
        name = "updateForecastCoef"
        available_since = '2.0'
        httpMethod = Route.POST
        path = "/nitro/projects/{project_ID}/datasets/{dataset_ID}/forecasts/{forecast_ID}/tunes/updatecoef"
        _path_keys = {
            'project_ID': Route.VALIDATOR_OBJECTID,
            'dataset_ID': Route.VALIDATOR_OBJECTID,
            'forecast_ID': Route.VALIDATOR_OBJECTID
        }

    class _deleteForecast(Route):
        name = "deleteForecast"
        httpMethod = Route.POST
        path = "/nitro/projects/{project_ID}/datasets/{dataset_ID}/forecasts/{forecast_ID}/delete"
        _path_keys = {
            'project_ID': Route.VALIDATOR_OBJECTID,
            'dataset_ID': Route.VALIDATOR_OBJECTID,
            'forecast_ID': Route.VALIDATOR_OBJECTID
        }

    class _getForecastTunes(Route):
        name = "getForecastTunes"
        httpMethod = Route.GET
        available_since = "1.0"
        removed_since = "3.0"
        path = "/nitro/projects/{project_ID}/datasets/{dataset_ID}/forecasts/{forecast_ID}/tunes"
        _path_keys = {
            'project_ID': Route.VALIDATOR_OBJECTID,
            'dataset_ID': Route.VALIDATOR_OBJECTID,
            'forecast_ID': Route.VALIDATOR_OBJECTID
        }

        class _postForecastTunes(SubRoute):
            name = "getForecastTunes"
            httpMethod = Route.POST
            available_since = "3.0"
            path = "/nitro/projects/{project_ID}/datasets/{dataset_ID}/forecasts/{forecast_ID}/tunes"
            _path_keys = {
                'project_ID': Route.VALIDATOR_OBJECTID,
                'dataset_ID': Route.VALIDATOR_OBJECTID,
                'forecast_ID': Route.VALIDATOR_OBJECTID
            }

    class _updateForecastTunes(Route):
        name = "updateForecastTunes"
        httpMethod = Route.POST
        path = "/nitro/projects/{project_ID}/datasets/{dataset_ID}/forecasts/{forecast_ID}/tunes/update"
        _path_keys = {
            'project_ID': Route.VALIDATOR_OBJECTID,
            'dataset_ID': Route.VALIDATOR_OBJECTID,
            'forecast_ID': Route.VALIDATOR_OBJECTID
        }

    class _getForecastTunesGroupBy(Route):
        name = "getForecastTunesGroupBy"
        httpMethod = Route.POST
        available_since = "6.4.0"
        path = "/nitro/projects/{project_ID}/datasets/{dataset_ID}/forecasts/{forecast_ID}/tunes/groupBy"
        _path_keys = {
            'project_ID': Route.VALIDATOR_OBJECTID,
            'dataset_ID': Route.VALIDATOR_OBJECTID,
            'forecast_ID': Route.VALIDATOR_OBJECTID
        }

    class _getForecastTunesAggregate(Route):
        name = "getForecastTunesAggregateGeo"
        httpMethod = Route.GET
        available_since = "1.0"
        removed_since = "3.0"
        path = "/nitro/projects/{project_ID}/datasets/{dataset_ID}/forecasts/{forecast_ID}/tunes/aggregate"
        _path_keys = {
            'project_ID': Route.VALIDATOR_OBJECTID,
            'dataset_ID': Route.VALIDATOR_OBJECTID,
            'forecast_ID': Route.VALIDATOR_OBJECTID
        }

    class _getForecastTunesAggregateGeo(Route):
        name = "getForecastTunesAggregateGeo"
        httpMethod = Route.POST
        available_since = "3.0"
        path = "/nitro/projects/{project_ID}/datasets/{dataset_ID}/forecasts/{forecast_ID}/tunes/aggregate/geo"
        _path_keys = {
            'project_ID': Route.VALIDATOR_OBJECTID,
            'dataset_ID': Route.VALIDATOR_OBJECTID,
            'forecast_ID': Route.VALIDATOR_OBJECTID
        }

    class _getForecastTunesAggregateDepot(Route):
        name = "getForecastTunesAggregateDepot"
        httpMethod = Route.POST
        available_since = "3.0"
        path = "/nitro/projects/{project_ID}/datasets/{dataset_ID}/forecasts/{forecast_ID}/tunes/aggregate/depot"
        _path_keys = {
            'project_ID': Route.VALIDATOR_OBJECTID,
            'dataset_ID': Route.VALIDATOR_OBJECTID,
            'forecast_ID': Route.VALIDATOR_OBJECTID
        }

    class _getForecastTunesAggregateEdition(Route):
        name = "getForecastTunesAggregateEdition"
        httpMethod = Route.POST
        available_since = "4.2.10"
        path = "/nitro/projects/{project_ID}/datasets/{dataset_ID}/forecasts/{forecast_ID}/tunes/aggregate/edition"
        _path_keys = {
            'project_ID': Route.VALIDATOR_OBJECTID,
            'dataset_ID': Route.VALIDATOR_OBJECTID,
            'forecast_ID': Route.VALIDATOR_OBJECTID
        }

    class _publishForecastTunes(Route):
        name = "publishForecastTunes"
        httpMethod = Route.POST
        available_since = "4.2.12"
        path = "/nitro/projects/{project_ID}/datasets/{dataset_ID}/forecasts/{forecast_ID}/tunes/publish"
        _path_keys = {
            'project_ID': Route.VALIDATOR_OBJECTID,
            'dataset_ID': Route.VALIDATOR_OBJECTID,
            'forecast_ID': Route.VALIDATOR_OBJECTID
        }

    class _exportForecastTunes(Route):
        name = "exportForecastTunes"
        httpMethod = Route.GET
        available_since = "3.0"
        path = "/nitro/projects/{project_ID}/datasets/{dataset_ID}/forecasts/{forecast_ID}/tunes/export"
        _path_keys = {
            'project_ID': Route.VALIDATOR_OBJECTID,
            'dataset_ID': Route.VALIDATOR_OBJECTID,
            'forecast_ID': Route.VALIDATOR_OBJECTID
        }

    class _exportReport(Route):
        name = "exportReport"
        available_since = '2.0'
        httpMethod = Route.GET
        path = "/nitro/projects/{project_ID}/datasets/{dataset_ID}/forecasts/{forecast_ID}/tunes/exportreport"
        _path_keys = {
            'project_ID': Route.VALIDATOR_OBJECTID,
            'dataset_ID': Route.VALIDATOR_OBJECTID,
            'forecast_ID': Route.VALIDATOR_OBJECTID
        }

    class _getForecastTunesStats(Route):
        name = "getForecastTunesStats"
        available_since = '3.0.2'
        httpMethod = Route.POST
        path = "/nitro/projects/{project_ID}/datasets/{dataset_ID}/forecasts/{forecast_ID}/tunes/stats"
        _path_keys = {
            'project_ID': Route.VALIDATOR_OBJECTID,
            'dataset_ID': Route.VALIDATOR_OBJECTID,
            'forecast_ID': Route.VALIDATOR_OBJECTID
        }

    class _getForecastTunesMetadata(Route):
        name = "getForecastTunesMetadata"
        available_since = '4.2.2'
        removed_since = '4.2.3'
        httpMethod = Route.GET
        path = "/nitro/projects/{project_ID}/datasets/{dataset_ID}/forecasts/{forecast_ID}/tunes/metadata"
        _path_keys = {
            'project_ID': Route.VALIDATOR_OBJECTID,
            'dataset_ID': Route.VALIDATOR_OBJECTID,
            'forecast_ID': Route.VALIDATOR_OBJECTID
        }

    class _getForecastMetadata(Route):
        name = "getForecastMetadata"
        available_since = '4.2.3'
        removed_since = '4.2.9'
        httpMethod = Route.GET
        path = "/nitro/projects/{project_ID}/datasets/{dataset_ID}/forecasts/metadata"
        _path_keys = {
            'project_ID': Route.VALIDATOR_OBJECTID,
            'dataset_ID': Route.VALIDATOR_OBJECTID
        }

    class _getForecastIdMetadata(Route):
        name = "getForecastIdMetadata"
        available_since = '4.2.9'
        httpMethod = Route.GET
        path = "/nitro/projects/{project_ID}/datasets/{dataset_ID}/forecasts/{forecast_ID}/metadata"
        _path_keys = {
            'project_ID': Route.VALIDATOR_OBJECTID,
            'dataset_ID': Route.VALIDATOR_OBJECTID,
            'forecast_ID': Route.VALIDATOR_OBJECTID
        }

    class _getForecastIdLayout(Route):
        name = "getForecastIdLayout"
        available_since = '6.3'
        httpMethod = Route.GET
        path = "/nitro/projects/{project_ID}/datasets/{dataset_ID}/forecasts/{forecast_ID}/layout"
        _path_keys = {
            'project_ID': Route.VALIDATOR_OBJECTID,
            'dataset_ID': Route.VALIDATOR_OBJECTID,
            'forecast_ID': Route.VALIDATOR_OBJECTID
        }

    class _getForecastTunesModalities(Route):
        name = "getForecastTunesModalities"
        available_since = '4.2.2'
        httpMethod = Route.POST
        path = "/nitro/projects/{project_ID}/datasets/{dataset_ID}/forecasts/{forecast_ID}/tunes/modalities"
        _path_keys = {
            'project_ID': Route.VALIDATOR_OBJECTID,
            'dataset_ID': Route.VALIDATOR_OBJECTID,
            'forecast_ID': Route.VALIDATOR_OBJECTID
        }

    class _getPosRecurrences(Route):
        name = "getPosRecurrences"
        httpMethod = Route.POST
        available_since = "4.2.10"
        path = "/nitro/projects/{project_ID}/datasets/{dataset_ID}/pos/recurrences"
        _path_keys = {
            'project_ID': Route.VALIDATOR_OBJECTID,
            'dataset_ID': Route.VALIDATOR_OBJECTID
        }

    class _updatePosRecurrences(Route):
        name = "updatePosRecurrences"
        httpMethod = Route.POST
        available_since = "4.2.10"
        path = "/nitro/projects/{project_ID}/datasets/{dataset_ID}/pos/recurrences/update"
        _path_keys = {
            'project_ID': Route.VALIDATOR_OBJECTID,
            'dataset_ID': Route.VALIDATOR_OBJECTID
        }

    class _getPosRecurrencesModalities(Route):
        name = "getPosRecurrencesModalities"
        httpMethod = Route.POST
        available_since = "4.2.10"
        path = "/nitro/projects/{project_ID}/datasets/{dataset_ID}/pos/recurrences/modalities"
        _path_keys = {
            'project_ID': Route.VALIDATOR_OBJECTID,
            'dataset_ID': Route.VALIDATOR_OBJECTID
        }

    class _checkFormula(Route):
        name = "checkFormula"
        available_since = '4.2.10'
        httpMethod = Route.POST
        path = "/nitro/projects/{project_ID}/datasets/{dataset_ID}/forecasts/{forecast_ID}/checkFormula"
        _path_keys = {
            'project_ID': Route.VALIDATOR_OBJECTID,
            'dataset_ID': Route.VALIDATOR_OBJECTID,
            'forecast_ID': Route.VALIDATOR_OBJECTID
        }

    class _getPosRecurrencesStats(Route):
        name = "getPosRecurrencesStats"
        httpMethod = Route.POST
        available_since = "4.2.10"
        path = "/nitro/projects/{project_ID}/datasets/{dataset_ID}/pos/recurrences/stats"
        _path_keys = {
            'project_ID': Route.VALIDATOR_OBJECTID,
            'dataset_ID': Route.VALIDATOR_OBJECTID
        }

    class _getPosRecurrencesMetadata(Route):
        name = "getPosRecurrencesMetadata"
        httpMethod = Route.GET
        available_since = "5.0"
        path = "/nitro/projects/{project_ID}/datasets/{dataset_ID}/pos/recurrences/metadata"
        _path_keys = {
            'project_ID': Route.VALIDATOR_OBJECTID,
            'dataset_ID': Route.VALIDATOR_OBJECTID
        }

    class _getPosRecurrencesLayout(Route):
        name = "getPosRecurrencesLayout"
        httpMethod = Route.GET
        available_since = "6.3"
        path = "/nitro/projects/{project_ID}/datasets/{dataset_ID}/pos/recurrences/layout"
        _path_keys = {
            'project_ID': Route.VALIDATOR_OBJECTID,
            'dataset_ID': Route.VALIDATOR_OBJECTID
        }

    class _getAtypicalDatesMetadata(Route):
        name = "getAtypicalDatesMetadata"
        httpMethod = Route.GET
        available_since = "6.2"
        path = "/nitro/projects/{project_ID}/datasets/{dataset_ID}/atypicalDates/metadata"
        _path_keys = {
            'project_ID': Route.VALIDATOR_OBJECTID,
            'dataset_ID': Route.VALIDATOR_OBJECTID
        }

    class _getAtypicalDatesLayout(Route):
        name = "getAtypicalDatesLayout"
        httpMethod = Route.GET
        available_since = "6.3"
        path = "/nitro/projects/{project_ID}/datasets/{dataset_ID}/atypicalDates/layout"
        _path_keys = {
            'project_ID': Route.VALIDATOR_OBJECTID,
            'dataset_ID': Route.VALIDATOR_OBJECTID
        }

    class _getAtypicalDatesHash(Route):
        name = "getAtypicalDatesHash"
        httpMethod = Route.GET
        available_since = "6.2"
        path = "/nitro/projects/{project_ID}/datasets/{dataset_ID}/atypicalDates/hash"
        _path_keys = {
            'project_ID': Route.VALIDATOR_OBJECTID,
            'dataset_ID': Route.VALIDATOR_OBJECTID
        }

    class _getAtypicalDatesStats(Route):
        name = "getAtypicalDatesStats"
        httpMethod = Route.POST
        available_since = "6.2"
        path = "/nitro/projects/{project_ID}/datasets/{dataset_ID}/atypicalDates/stats"
        _path_keys = {
            'project_ID': Route.VALIDATOR_OBJECTID,
            'dataset_ID': Route.VALIDATOR_OBJECTID
        }

    class _getAtypicalDates(Route):
        name = "getAtypicalDates"
        httpMethod = Route.POST
        available_since = "6.2"
        path = "/nitro/projects/{project_ID}/datasets/{dataset_ID}/atypicalDates"
        _path_keys = {
            'project_ID': Route.VALIDATOR_OBJECTID,
            'dataset_ID': Route.VALIDATOR_OBJECTID
        }

    class _createAtypicalDates(Route):
        name = "createAtypicalDates"
        httpMethod = Route.POST
        available_since = "6.2"
        path = "/nitro/projects/{project_ID}/datasets/{dataset_ID}/atypicalDates/create"
        _path_keys = {
            'project_ID': Route.VALIDATOR_OBJECTID,
            'dataset_ID': Route.VALIDATOR_OBJECTID
        }

    class _updateAtypicalDates(Route):
        name = "updateAtypicalDates"
        httpMethod = Route.POST
        available_since = "6.2"
        path = "/nitro/projects/{project_ID}/datasets/{dataset_ID}/atypicalDates/update"
        _path_keys = {
            'project_ID': Route.VALIDATOR_OBJECTID,
            'dataset_ID': Route.VALIDATOR_OBJECTID
        }

    class _deleteAtypicalDates(Route):
        name = "deleteAtypicalDates"
        httpMethod = Route.POST
        available_since = "6.2"
        path = "/nitro/projects/{project_ID}/datasets/{dataset_ID}/atypicalDates/delete"
        _path_keys = {
            'project_ID': Route.VALIDATOR_OBJECTID,
            'dataset_ID': Route.VALIDATOR_OBJECTID
        }

    class _getNitroDashboards(Route):
        name = "getNitroDashboards"
        httpMethod = Route.GET
        available_since = '6.2'
        path = "/nitro/projects/{project_ID}/datasets/{dataset_ID}/dashboards"
        _path_keys = {
            'project_ID': Route.VALIDATOR_OBJECTID,
            'dataset_ID': Route.VALIDATOR_OBJECTID
        }

    class _addNitroDashboard(Route):
        name = "addNitroDashboard"
        httpMethod = Route.POST
        available_since = '6.2'
        path = "/nitro/projects/{project_ID}/datasets/{dataset_ID}/dashboards"
        _path_keys = {
            'project_ID': Route.VALIDATOR_OBJECTID,
            'dataset_ID': Route.VALIDATOR_OBJECTID
        }

    class _getNitroDashboard(Route):
        name = "getNitroDashboard"
        httpMethod = Route.GET
        available_since = '6.2'
        path = "/nitro/projects/{project_ID}/datasets/{dataset_ID}/dashboards/{dashboard_ID}"
        _path_keys = {
            'project_ID': Route.VALIDATOR_OBJECTID,
            'dataset_ID': Route.VALIDATOR_OBJECTID,
            'dashboard_ID': Route.VALIDATOR_OBJECTID
        }

    class _updateNitroDashboard(Route):
        name = "updateNitroDashboard"
        available_since = '6.2'
        httpMethod = Route.POST
        path = "/nitro/projects/{project_ID}/datasets/{dataset_ID}/dashboards/{dashboard_ID}"
        _path_keys = {
            'project_ID': Route.VALIDATOR_OBJECTID,
            'dataset_ID': Route.VALIDATOR_OBJECTID,
            'dashboard_ID': Route.VALIDATOR_OBJECTID
        }

    class _exportNitroDashboard(Route):
        name = "exportNitroDashboard"
        available_since = '6.2'
        httpMethod = Route.POST
        path = "/nitro/projects/{project_ID}/datasets/{dataset_ID}/dashboards/{dashboard_ID}/export"
        _path_keys = {
            'project_ID': Route.VALIDATOR_OBJECTID,
            'dataset_ID': Route.VALIDATOR_OBJECTID,
            'dashboard_ID': Route.VALIDATOR_OBJECTID
        }

    class _deleteNitroDashboard(Route):
        name = "deleteNitroDashboard"
        httpMethod = Route.POST
        available_since = '6.2'
        path = "/nitro/projects/{project_ID}/datasets/{dataset_ID}/dashboards/{dashboard_ID}/delete"
        _path_keys = {
            'project_ID': Route.VALIDATOR_OBJECTID,
            'dataset_ID': Route.VALIDATOR_OBJECTID,
            'dashboard_ID': Route.VALIDATOR_OBJECTID
        }

    class _getNitroCustomQuantiles(Route):
        name = "getNitroCustomQuantiles"
        httpMethod = Route.GET
        available_since = '6.4'
        path = "/nitro/projects/{project_ID}/quantiles/{quantiles_clusters_ID}"
        _path_keys = {
            'project_ID': Route.VALIDATOR_OBJECTID,
            'quantiles_clusters_ID': Route.VALIDATOR_OBJECTID_OR_EMPTY
        }

    class _createNitroCustomQuantiles(Route):
        name = "getNitroCustomQuantiles"
        httpMethod = Route.POST
        available_since = '6.4'
        path = "/nitro/projects/{project_ID}/quantiles/create"
        _path_keys = {
            'project_ID': Route.VALIDATOR_OBJECTID
        }

    class _updateNitroCustomQuantiles(Route):
        name = "getNitroCustomQuantiles"
        httpMethod = Route.POST
        available_since = '6.4'
        path = "/nitro/projects/{project_ID}/quantiles/{quantiles_clusters_ID}/update"
        _path_keys = {
            'project_ID': Route.VALIDATOR_OBJECTID,
            'quantiles_clusters_ID': Route.VALIDATOR_OBJECTID
        }

    class _deleteNitroCustomQuantiles(Route):
        name = "getNitroCustomQuantiles"
        httpMethod = Route.POST
        available_since = '6.4'
        path = "/nitro/projects/{project_ID}/quantiles/{quantiles_clusters_ID}/delete"
        _path_keys = {
            'project_ID': Route.VALIDATOR_OBJECTID,
            'quantiles_clusters_ID': Route.VALIDATOR_OBJECTID
        }
