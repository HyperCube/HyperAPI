from hdp_lib_api.base.resource import Resource
from hdp_lib_api.base.route import Route, SubRoute


class Distance(Resource):
    name = "distance"
    available_since = "5.0.0"
    removed_since = None

    class _getDistances(Route):
        name = "getDistances"
        removed_since = "6.0.0"
        httpMethod = Route.GET
        path = "/projects/{project_ID}/distances"
        _path_keys = {
            'project_ID': Route.VALIDATOR_OBJECTID
        }

        class _getDistances_v60(SubRoute):
            name = "getDistances"
            available_since = "6.0.0"
            httpMethod = Route.GET
            path = "/swp/projects/{project_ID}/distances"
            _path_keys = {
                'project_ID': Route.VALIDATOR_OBJECTID
            }

    class _setDistances(Route):
        name = "setDistances"
        removed_since = "6.0.0"
        httpMethod = Route.POST
        path = "/projects/{project_ID}/distances"
        _path_keys = {
            'project_ID': Route.VALIDATOR_OBJECTID
        }

        class _setDistances_v60(SubRoute):
            name = "setDistances"
            available_since = "6.0.0"
            httpMethod = Route.POST
            path = "/swp/projects/{project_ID}/distances"
            _path_keys = {
                'project_ID': Route.VALIDATOR_OBJECTID
            }
