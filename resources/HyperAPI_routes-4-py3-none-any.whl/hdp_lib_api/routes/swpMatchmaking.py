from hdp_lib_api.base.resource import Resource
from hdp_lib_api.base.route import Route, SubRoute


class SWPMatchmaking(Resource):
    name = "swpMatchmaking"
    available_since = "3.0"
    removed_since = None

    class _getAgents(Route):
        name = "getAgents"
        removed_since = "6.0.0"
        httpMethod = Route.GET
        path = "/projects/{project_ID}/redeployments/{work_ID}/agents"
        _path_keys = {
            'project_ID': Route.VALIDATOR_OBJECTID,
            'work_ID': Route.VALIDATOR_OBJECTID,
        }

        class _getAgents_v60(SubRoute):
            name = "getAgents"
            available_since = "6.0.0"
            httpMethod = Route.GET
            path = "/swp/projects/{project_ID}/redeployments/{work_ID}/agents"
            _path_keys = {
                'project_ID': Route.VALIDATOR_OBJECTID,
                'work_ID': Route.VALIDATOR_OBJECTID,
            }

    class _getOptimizationDetail(Route):
        name = "getOptimizationDetail"
        httpMethod = Route.GET
        available_since = "3.1"
        removed_since = "6.0.0"
        path = "/projects/{project_ID}/redeployments/{work_ID}/optimizationDetail"
        _path_keys = {
            'project_ID': Route.VALIDATOR_OBJECTID,
            'work_ID': Route.VALIDATOR_OBJECTID,
        }

        class _getOptimizationDetail_v60(SubRoute):
            name = "getOptimizationDetail"
            available_since = "6.0.0"
            httpMethod = Route.GET
            path = "/swp/projects/{project_ID}/redeployments/{work_ID}/optimizationDetail"
            _path_keys = {
                'project_ID': Route.VALIDATOR_OBJECTID,
                'work_ID': Route.VALIDATOR_OBJECTID,
            }

    class _getMatches(Route):
        name = "getMatches"
        removed_since = "6.0.0"
        httpMethod = Route.GET
        path = "/projects/{project_ID}/redeployments/{work_ID}/agents/{agent_ID}"
        _path_keys = {
            'project_ID': Route.VALIDATOR_OBJECTID,
            'work_ID': Route.VALIDATOR_OBJECTID,
            'agent_ID': Route.VALIDATOR_ANY,
        }

        class _getMatches_v60(SubRoute):
            name = "getMatches"
            available_since = "6.0.0"
            httpMethod = Route.GET
            path = "/swp/projects/{project_ID}/redeployments/{work_ID}/agents/{agent_ID}"
            _path_keys = {
                'project_ID': Route.VALIDATOR_OBJECTID,
                'work_ID': Route.VALIDATOR_OBJECTID,
                'agent_ID': Route.VALIDATOR_ANY,
            }
