from hdp_lib_api.base.resource import Resource
from hdp_lib_api.base.route import Route, SubRoute


class Workalendar(Resource):
    name = "workalendar"
    available_since = "1.0"
    removed_since = None

    class _getWorkalendarCountries(Route):
        name = "getWorkalendarCountries"
        httpMethod = Route.GET
        path = "/workalendar/countries"
        removed_since = "5.0"

        class _getWorkalendarCountries_platformservices(SubRoute):
            available_since = "5.0"
            httpMethod = Route.GET
            path = "/platformservices/workalendar/countries"

    class _getWorkalendarWorkingDays(Route):
        available_since = "5.0"
        name = "getWorkalendarWorkingDays"
        httpMethod = Route.POST
        path = "/platformservices/workalendar/workingdays"
