try:
    from hdp_lib_api.package_metadata import __version__
except ImportError:
    __version__ = 0

from hdp_lib_api.base.router import Router  # noqa: F401
